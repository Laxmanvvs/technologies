<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller; 
use DB;
class RegisterController extends Controller
{
    
	 public function index(){ 
 //echo "hello";
	 	return view('register');
 } 

// public function authenticate()
//     {
//         if (Auth::attempt(['email' => $email, 'password' => $password])) {
//             // Authentication passed...
//             return redirect()->intended('dashboard');
//         }
//     }


 public function show(request $request){ 
 //echo "hello";
 	 echo "<pre>";
 	$username=$request->username;
 	echo $username;
 	$password=$request->password;

 	$pass=md5($password);
 	echo $pass;
 	$email=$request->email;
 	echo $email;
 	//print_r($_POST);
//exit;
 	 $gender=$request->gender;

 	 $qualify=$request->qualify;
 	  DB::insert('insert into registration (username,password,email,gender,qualification) values(?,?,?,?,?)',[$username,$pass,$email,$gender,$qualify]); 
 	//  return redirect("/fetch"); 	  
 } 
    
}







