<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\Hash;

use App\Http\Controllers\Controller; 
use DB;

use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    
	 public function index(){ 

	 	return view('login');
 } 


// public function show(request $request){ 
 
// $username=$request->username;
//  	echo $username;
//  	$password=$request->password;
//  	echo $password;

//  	// $user=$_SESSION[$username];
//  	// echo $user;
//  }

 public function authenticate(request $request)
    {
       

    	$username=$request->username;
 	echo $username;
 	$password=$request->password;
 	echo $password;
    $pass = Hash::make($password);

        if (Auth::attempt(['name' => $username, 'password' => $pass])) {
            // Authentication passed...
            echo "username and password are  authenticated";
        }
    
    
    else 
    {
    	echo "username and password are not authenticated";
     }

 }


 public function show(request $request){ 
 //echo "hello";
     echo "<pre>";
    $username=$request->username;
    echo $username;
    $password=$request->password;

    $pass=md5($password);
    echo $pass;
    $email=$request->email;
    echo $email;
    //print_r($_POST);
//exit;
    // $gender=$request->gender;

    // $qualify=$request->qualify;
      DB::insert('insert into users (name,email,password) values(?,?,?)',[$username,$email,$pass]); 
    //  return redirect("/fetch");    
 } 
}
