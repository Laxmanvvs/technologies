<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Http\Controllers\Controller; 
use DB;

class FetchController extends Controller
{
    public function index(request $request){

         $users=DB::select("select * from registration");
         echo "<pre>";
print_r($users);
?>


<table border="1" color="black"  >
<tr>
<th> ID </th>
<th> USERNAME </th>
<th> PASSWORD </th>
<th> EMAIL </th>
<th> GENDER </th>
<th> QUALIFICATION </th>
</tr>
<?php
    	foreach ($users as $use)
        {
        	 // $use->render(); 
     ?>   	
          <tr>
<td><?php $id=$use->registration_id; echo $id;?> </td>
<td><?php $username=$use->username; echo $username;?> </td>
<td><?php $password=$use->password;  echo $password;?> </td>
<td><?php $email=$use->email; echo $email;?> </td>
<td><?php $gender=$use->gender; echo $gender;?> </td>
<td><?php $qualification=$use->qualification; echo $qualification;?> </td>
</tr>
        
<?php

        }
       }

    public function id(request $request){
       $id=$request->id;
     //  echo $id;
 $users = DB::select('select username,password from registration where registration_id = ?',[$id]);
 // print_r($users);

    	foreach ($users as $use)
        {
          $username=$use->username; 
          echo "username:".$username;
          $password=$use->password; echo "<br>";
        echo "password:".$password;
        }

}     

}
