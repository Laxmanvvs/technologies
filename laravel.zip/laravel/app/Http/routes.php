<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/auth','LoginController@index'); 
Route::post('/check','LoginController@show');
Route::post('/killer','LoginController@authenticate');


 Route::post("/register/{username}/{password}/{email}/{gender}/{qualification}",'RegisterController@show');





Route::get('/input','RegisterController@index'); 
Route::post('/registration','RegisterController@show');

Route::get('/fetch','FetchController@index'); 

Route::get("/fetch/{id}", 'FetchController@id');
 Route::get("/fetch/{id}", 'FetchController@id');
   

Route::get("/fetch/{id}", 'FetchController@id');




Route::auth();

Route::get('/home', 'HomeController@index');
