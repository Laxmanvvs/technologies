
<html> 
<head> 
 <title>Form Example</title> 
</head> 
<body> 
 <form action="/registration" method="POST"> 
 <input type="hidden" name="_token" value="<?php echo csrf_token() ?>"> 
  <table> 
   
   <tr> 
    <td>Username</td> 
    <td><input type="text" name="username" /></td> 
   </tr> 
   <tr> 
    <td>Password</td> 
    <td><input type="password" name="password" /></td> 
   </tr> 
   <tr>
 <td>Email</td> 
    <td><input type="email" name="email" /></td> 
   </tr>
<tr> 
    <td>Gender</td> 
    <td><input type="radio" name="gender"  value="male" id='checkbox' />Male</td>
    <td><input type="radio" name="gender" value="female" id='checkbox'/>  Female  </td> 
    <td><input type="radio" name="gender" value="Others" id='checkbox'/> Others   </td> 
   </tr>
   <tr>
   <td>Qualification</td>
   <td><select name="qualify" multiple>
  <option value="ece">ECE</option>
  <option value="eee">EEE</option>
  <option value="it">IT</option>
  <option value="cse">CSE</option>
</select></td>
</tr>

   <tr> 
 <td>   <input type="submit" value="Register" name="submit"/> </td>
   </tr> 
  </table> 

 </form> 
</body> 
</html>  


<script>


$("input:radio").on('click', function() {
 
  var $box = $(this);
  if ($box.is(":checked")) {
   
    var group = "input:radio[name='" + $box.attr("name") + "']";
   
    $(group).prop("checked", false);
    $box.prop("checked", true);
  } else {
    $box.prop("checked", false);
  }
});
</script>










